# 📸 DeepFace Attendance App

An AI-powered student attendance system using **face verification** technology!  
Built with **React Native + Expo**, **FastAPI backend**, and **DeepFace** for facial recognition.

---

## 🚀 Features

- ✅ Student login and authentication (JWT tokens)
- ✅ Dashboard showing courses and attendance status
- ✅ Search for courses
- ✅ View detailed course info
- ✅ Mark attendance by capturing live photo 📸
- ✅ Face verification against registered profile
- ✅ Attendance is recorded only if face matches ✅
- ✅ Full-stack project (Frontend + Backend)

---

## 🛠️ Tech Stack

| Frontend | Backend | AI |
|:--------|:--------|:---|
| React Native (Expo Router) | FastAPI (Python) | DeepFace (Facial Recognition) |
| Tailwind CSS (NativeWind) | PostgreSQL / SQLite | OpenCV |
| Context API (for Auth State) | JWT Authentication | Pre-trained FaceNet Model |

---

## ⚙️ Setup Instructions

### Backend (FastAPI)

1. Clone the repo
2. Create and activate virtual environment
3. Install Python dependencies:

```bash
pip install -r requirements.txt
Run backend server:

bash
Copy
Edit
uvicorn backend.main:app --reload --host 0.0.0.0 --port 8000
Backend will be available at:

arduino
Copy
Edit
http://localhost:8000
(Or http://<your-ip>:8000 for mobile testing)

Frontend (React Native)
Go into frontend folder

Install dependencies:

bash
Copy
Edit
npm install
Install Expo CLI if not installed:

bash
Copy
Edit
npm install -g expo-cli
Run the app:

bash
Copy
Edit
expo start
Scan the QR code with your Expo Go app 📱

📸 How It Works
Student logs into the app ✅

Dashboard shows list of enrolled courses 📚

Student selects a course and clicks Mark Attendance 📍

App opens camera to capture a live photo 📸

Photo is sent to backend /verify_face/?course_id=...

DeepFace compares captured image with stored profile image 🤖

If faces match ➡️ Attendance is recorded!

If faces don't match ➡️ Attendance rejected ❌

📂 Project Structure
bash
Copy
Edit
Attendance-backend/
  ├── backend/
  │   ├── main.py        # FastAPI app
  │   ├── models.py      # Database models
  │   ├── auth.py        # Authentication utils
  │   ├── database.py    # DB setup
  └── requirements.txt   # Python dependencies

Attendance-frontend/
  ├── app/
  │   ├── (tabs)/         # Main tabs like Dashboard, Courses, Attendance
  │   ├── screens/        # Attendance screen
  │   ├── contexts/       # AuthContext
  │   ├── api/            # API Services (fetchCourses, fetchAttendance)
  │   ├── courseData.ts   # (Old, now removed)
  └── package.json        # Project setup
🎯 Future Improvements
Profile image upload screen (first-time users)

Admin panel for viewing all attendances

Attendance History page

Push Notifications for attendance reminder

Deploy backend with Render / Railway free hosting

Face verification confidence tuning (DeepFace distance metrics)

🙌 Acknowledgements
DeepFace for facial recognition

FastAPI for backend APIs

Expo for mobile app framework

NativeWind for Tailwind CSS in React Native

✨ Demo
📹 [Optionally insert video demo here]
(If you record a small demo using your phone!)

💬 Contact
Made with ❤️ by [Your Name]

[LinkedIn Profile]
[GitHub Profile]
[Personal Portfolio Website]